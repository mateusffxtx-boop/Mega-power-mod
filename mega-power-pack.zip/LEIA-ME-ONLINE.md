# Mega Power Pack - jogando online

O mod funciona em **LAN (host local)** e em **servidor dedicado com mods**. Ele cria conteúdo novo
(blocos, itens, unidade), então NÃO é "escondido" (`hidden: false`): todo jogador precisa ter o mesmo mod.

## Regras para todos
1. Mesma versão do jogo (testado com a build 160.7).
2. Mesmo mod, mesma versão (`version` no mod.hjson, hoje 2.2). Versões diferentes recusam a conexão.
3. Instale o `mega-power-pack.zip` na pasta de mods de cada jogador (não precisa descompactar).

## Jogar em rede local (LAN)
1. O anfitrião abre o jogo com o mod, entra em um mapa e hospeda (Jogar > Multijogador > Hospedar).
2. Os outros jogadores, na mesma rede, instalam o mesmo zip e entram pelo IP do anfitrião.
3. Quem hospeda gera os minérios novos; os outros recebem tudo junto com o mapa.

## Servidor dedicado
1. Coloque o zip na pasta `config/mods/` do servidor (ao lado do `server-release.jar`).
2. Inicie o servidor. No console, o comando `mods` deve listar "Mega Power Pack".
3. Cada jogador instala o mesmo zip antes de entrar.

## O que foi adaptado para o online
- Geração de minérios (chão e parede) roda só no anfitrião/servidor e viaja junto com o mapa.
- A escolha do Fabricador Universal é sincronizada pela rede (configuração oficial do jogo).
- Os scripts não usam nada de tela, então funcionam em servidor sem interface.
- Beta Hiper (insta build) vale para todos os jogadores. Se o servidor não quiser isso, apague as linhas
  "Jogador" no fim do `scripts/main.js` (os núcleos voltam a gerar Alpha/Beta/Gamma).
