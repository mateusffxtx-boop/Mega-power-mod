# Mega Power Pack - passo a passo para continuar com outra IA

## Contexto
Mod de Mindustry (build 160.7 / v8) em HJSON + JS. Arquivo: mega-power-pack.zip (v2.2). Nomes de arquivo em kebab-case.

## Estado atual (v2.2)
- Esteira hiper: sprites regenerados (gen via Python/PIL, 5 tipos x 4 frames, 32x32 RGBA).
- Armas: metralhadora-eletrica, raio-hiper, missil-hiper, devastador-hiper (PowerTurret).
- Escudos: escudo-pequeno/medio/grande (ForceProjector).
- fabrica-universal-de-unidades e fabrica-universal-instantanea (UnitFactory, 35 unidades, 7 linhas T1-T5).
- melhorador-de-unidades e melhorador-de-unidades-instantaneo (Reconstructor; upgrades definidos em scripts/main.js).
- beta-hiper (unidade do jogador, content/units): insta build via buildSpeed 1000; main.js troca a unidade dos núcleos. O bloco ativador-insta-build foi removido por causar crash.
- Extras: parede-hiper(-grande), reparador-hiper, cofre-hiper.

## Adicionado na v1.8
- poste-de-energia-global (PowerNode, laserRange 700, maxNodes 500).
- bateria-hiper (Battery, consumes: { powerBuffered: 1000000 }) - se der erro, verificar essa chave.
- melhorador-de-maquinas-mega (x4, raio 200) e -ultra (x8, raio 360).
- lanca-foguetes-hiper (ItemTurret, size 4): carvão = alcance 560 (70 blocos), 5 foguetes, dano 300; areia (munição hyper) = rangeChange +560 (140 blocos), dano 500. Campo de munição em hjson é `ammoTypes`.
- Suposições a confirmar: "70" = 70 blocos (1 bloco = 8 unidades); "minério amarelo" = areia.

## Adicionado na v2.0: minérios e brocas
- 5 itens/minérios: ouro(5), rubi(6), safira(7), esmeralda(8), obsidiana(9) = dureza. Itens em content/items, overlays `OreBlock` em content/blocks/minerio-*.hjson (3 variações de sprite cada).
- scripts/main.js (`gerarMinerios`) espalha manchas desses minérios em mapas novos (marca `rules.tags` "mpp-minerios" para não repetir).
- 5 brocas `broca-nova-1..5` (tamanho 2-6, tier 12, energia 1/2.5/5/10/20). Cada uma exige os minérios da anterior (cadeia de progressão).
- Interpretação: "5 de cada" = 5 minérios e 5 brocas. Confirmar com o usuário.
- Pontos a testar: `type: OreBlock` + `itemDrop`, requisitos com itens do próprio mod (`ouro/40`), `rules.tags`.
- Gerador: ferramentas/gen_ores.py

## Adicionado na v2.1: especializadas, paredes e dificuldade
- Brocas de chão renomeadas por minério (ids broca-nova-1..5): Ouro, Rubi, Safira, Esmeralda, Obsidiana; cada uma com rotor de desenho diferente e 3x mais rápida no seu minério (`drillMultipliers`, definido em scripts/main.js dentro de try/catch).
- Minérios de parede: content/blocks/minerio-parede-*.hjson (`OreBlock` com `wallOre: true`); `gerarMinerosParede` em main.js espalha em paredes expostas (tag `mpp-paredes`).
- 5 perfuratrizes de parede `perfuratriz-1..5` (`BeamDrill`, alcance 6-14, energia 3-40), especializadas por minério.
- Geradores novos: gerador-colossal (30/tick) e gerador-titanico (120/tick), pedem minérios novos.
- DIFICULDADE GLOBAL (ferramentas/dificultar.py): todo bloco do mod com custo x3, consumo de energia x3 e `researchCostMultiplier: 4`. O script usa marcador na 1a linha do .hjson para não aplicar duas vezes; rode-o DEPOIS dos outros geradores (gen_*.py), que sobrescrevem os arquivos.
- Pontos a testar: `wallOre`, `BeamDrill` (alcance/sprites), `drillMultipliers`, setOverlay em paredes.

## Online (v2.2)
- `hidden: false` mantido (mod de conteúdo; clientes precisam do mesmo mod/versão).
- scripts/main.js: helper `aoCarregar(fn)` usa ContentInitEvent (ou ClientLoadEvent + ServerLoadEvent) para funcionar em servidor dedicado; geração de minérios ignora clientes (`Vars.net.client()`); `created()` do fabricador limpa seleção antiga; log de aviso ao carregar.
- Fabricadores já usavam `config(Item...)`/`configure()` (sincronizado). Seleção fica em mapa global `ESCOLHA` por posição.
- Guia para jogadores: LEIA-ME-ONLINE.md (dentro do zip e em outputs).
- Não testado em rede real. Pontos a validar: join de cliente em servidor com o mod, minérios de parede aparecendo para clientes.

## Capa e ícone
- capa-mega-power-pack.png (1280x720, sem texto, para GitHub/Discord) e icon.png (256x256, na raiz do mod, aparece no gerenciador de mods). Gerados por ferramentas/gen_capa.py.

## Balanceamento da v1.9 (valores de energia são por tick; o jogo mostra x60)
- Geradores: 0.1 / 0.3 / 0.9 / 2.5 / 8 (fraco → super).
- Brocas: drillTime 240/140/80, energia 0.8/2.2/5.5.
- Escudos: raio 90/150/240, vida 1200/4000/12000, energia 2/5/12.
- Armas: metralhadora 14 dano; raio 110; míssil 30+60 splash; devastador 1000; lança-foguetes reload 180 (dano 300/500 e alcance 70/140 blocos mantidos).
- Melhoradores Mega/Ultra: energia 7/15. O melhorador multiplica energia dos geradores com teto de 2,5x (scripts/main.js).
- Fabricador Universal: custos por item maiores (surge 12, plastanium 8...), normal 2 itens/s.
- Fábricas de unidades: custos por tier maiores; instantânea custa 1,5x. Melhoradores de unidades: 900 ticks, energia 12 (instantâneo 40).
- Limitação conhecida: os Melhoradores de Unidades não gastam itens (formato de `consumes: items` no HJSON não confirmado).

## Sprites
- gen_sprites2.py (Python/PIL) gera os sprites com sombreamento; a esteira hiper usa gen_sprites.py.

## Bug corrigido nesta versão
As duas fábricas deram erro ao carregar. Causa provável: objetos de uma linha dentro de `plans`
(`{ unit: x, requirements: [...], time: n }`); o parser HJSON do Mindustry lê valor sem aspas até o fim da linha.
Correção: cada plano agora está em várias linhas.

## Regras do HJSON do Mindustry
- Valores sem aspas vão até o fim da linha; em objetos, um campo por linha.
- Campos diferenciam maiúsculas de minúsculas.
- Sprites: PNG RGBA 32 bits, tamanho 32 x size.

## Adicionado na v2.3
- aracnideo-colossal (content/units, type: legs): health 26000, hitSize 60, 2 armas: "laser-gigante" (LaserBulletType, dano 900, comprimento 420) e "lancador-buraco-negro" (ArtilleryBulletType, splash 650/raio 75, status: slow para simular "puxão" de gravidade — não existe gravidade real sem Java custom).
- construtor-aracnideo-colossal (content/blocks, type: UnitFactory, size 7): consumes power 60, plans com 1 unidade (aracnideo-colossal), research parent fabrica-universal-de-unidades. SEM liga surge na receita (titanium/silicon/plastanium/thorium/metaglass).
- Sprites novos: aracnideo-colossal.png (corpo 60x60), aracnideo-colossal-leg.png, aracnideo-colossal-leg-base.png (padrão de unidade `legs`), construtor-aracnideo-colossal.png + -top.png (224x224, size7).
- Pontos a testar: campos legCount/legLength/legBaseOffset/legMoveSpace/legSpeed do tipo `legs` (não confirmados 100% nesta sessão, vieram de memória/convenção, não de teste em jogo); shootCone nas armas; se o `status: slow` realmente aplica lentidão ao ser atingido pela explosão.
- Não rodei ferramentas/dificultar.py nesses arquivos novos (sem marcador "dificuldade-v1" no topo) — rode manualmente se quiser aplicar a dificuldade global.

## Adicionado na v2.4 (visual, baseado em referências enviadas pelo usuário)
- buraco-negro-bullet.png (48x48, sprites/): disco de acreção roxo/branco com horizonte de eventos preto, glow em camadas, "estrelinhas" espalhadas. Referenciado via campo `sprite: "buraco-negro-bullet"` no bullet da arma "lancador-buraco-negro" (ArtilleryBulletType extends BasicBulletType, que tem campo `sprite` confirmado na wiki). NÃO testado se o nome resolve certo (pode precisar prefixo do mod, tipo `mega-power-pack-buraco-negro-bullet` — se a bala aparecer sem textura/com X rosa, esse é o primeiro lugar pra checar).
- aracnideo-colossal.png (corpo, 64x64) refeito: coroa de 10 picos escuros desenhados no próprio sprite do corpo + núcleo de buraco negro (miniatura do mesmo sprite acima) no abdômen.
- legCount 8→10, legLength 50→72, legBaseOffset 14→16 (pernas mais longas/numerosas pra ficar mais parecido com a referência de imagem que o usuário mandou — unidade tipo aranha com "espinhos" longos irradiando).
- Laser gigante: array de cores trocado pra gradiente roxo/azul/branco (mais parecido com a referência "Laser Cósmico").
- Pendência: a referência do usuário tinha animação em quadros (buraco negro "aparece → expande → forma disco → ativa gravidade → estável → impacto"); isso NÃO foi implementado — Mindustry não anima sprite de bala por frames via JSON puro, precisaria de script JS customizado hookando o update do bullet pra trocar de região ao longo da vida dele. Avisar o usuário que isso é só uma textura estática por enquanto.

## Pendências
1. Testar tudo no jogo e ler os erros (botão "Det" na tela de erro).
2. Confirmar se os Melhoradores de Unidades carregam (upgrades via JS em ContentInitEvent).
3. Equilibrar custos/energia e trocar os sprites gerados por arte final.
4. Ideias: mais armas, ponte hiper, gerador novo.
