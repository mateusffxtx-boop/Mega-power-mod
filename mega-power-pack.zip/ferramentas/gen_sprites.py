import math
from PIL import Image, ImageDraw

OUT = "/home/claude/mod/sprites/"
T = (0, 0, 0, 0)

# ------------------------------------------------------------------ esteira hiper
BASE = (104, 86, 158, 255)
DARK = (52, 36, 86, 255)
YEL = (255, 224, 92, 255)
OFF = {6: 0, 5: 1, 4: 1, 3: 2, 2: 3, 1: 3, 0: 4}  # formato do chevron (igual ao original)


def chevron_pixels(tip_s, path):
    """path(s, v) -> (x, y). Chevron com a ponta em tip_s ao longo do caminho."""
    px = []
    for v in range(-6, 7):
        ur = OFF[abs(v)] - 4          # borda da frente (<= 0)
        for u in range(ur - 4, ur + 1):  # espessura 5
            px.append(path(tip_s + u, v))
    return px


def conveyor_tile(kind, frame):
    im = Image.new("RGBA", (32, 32), BASE)
    d = ImageDraw.Draw(im)
    # bordas: (topo, base, esquerda)
    top, bot, left = {
        0: (1, 1, 0),  # reta
        1: (1, 0, 1),  # curva (entra por baixo, sai para a direita)
        2: (1, 0, 0),  # entrada lateral por baixo
        3: (0, 0, 0),  # entradas dos dois lados
        4: (1, 0, 1) if False else (0, 0, 1),  # fundo fechado
    }[kind]
    # chevrons primeiro, bordas por cima
    shift = 4 * frame
    if kind == 1:
        for k in range(-2, 4):
            tip = shift + 16 * k - 3
            if tip <= 15:      # trecho vertical: chevron apontando para cima
                tx, ty = 16, 31 - tip
                for v in range(-6, 7):
                    ur = OFF[abs(v)] - 4
                    for u in range(ur - 4, ur + 1):
                        x, y = tx + v, ty - u
                        if 0 <= x < 32 and 0 <= y < 32:
                            im.putpixel((x, y), YEL)
            else:              # trecho horizontal: chevron apontando para a direita
                tx, ty = 16 + (tip - 15), 16
                for v in range(-6, 7):
                    ur = OFF[abs(v)] - 4
                    for u in range(ur - 4, ur + 1):
                        x, y = tx + u, ty + v
                        if 0 <= x < 32 and 0 <= y < 32:
                            im.putpixel((x, y), YEL)
    else:
        def path(s, v):
            return ((int(s) % 32) if False else int(s), 16 + v)
        for k in range(-2, 3):
            tip = 8 + shift + 16 * k
            for (x, y) in chevron_pixels(tip, path):
                xx = x
                if kind == 4 and xx < 6:
                    continue
                if 0 <= xx < 32:
                    im.putpixel((xx, y), YEL)
    if top:
        d.rectangle([0, 0, 31, 5], fill=DARK)
    if bot:
        d.rectangle([0, 26, 31, 31], fill=DARK)
    if left:
        d.rectangle([0, 0, 5, 31], fill=DARK)
    # cantos sempre presentes
    for (cx, cy) in [(0, 0), (26, 0), (0, 26), (26, 26)]:
        d.rectangle([cx, cy, cx + 5, cy + 5], fill=DARK)
    return im


def make_conveyor():
    for i in range(5):
        for j in range(4):
            conveyor_tile(i, j).save(OUT + f"esteira-hiper-{i}-{j}.png")
    conveyor_tile(0, 0).save(OUT + "esteira-hiper.png")


# ------------------------------------------------------------------ helpers de bloco
def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c[:3]) + (255,)


def plate(n, base, dark, light=None):
    s = n * 32
    im = Image.new("RGBA", (s, s), T)
    d = ImageDraw.Draw(im)
    light = light or shade(base, 1.25)
    d.rectangle([0, 0, s - 1, s - 1], fill=dark)
    d.rectangle([3, 3, s - 4, s - 4], fill=base)
    d.line([3, 3, s - 4, 3], fill=light)
    d.line([3, 3, 3, s - 4], fill=light)
    d.line([3, s - 4, s - 4, s - 4], fill=shade(base, 0.7))
    d.line([s - 4, 3, s - 4, s - 4], fill=shade(base, 0.7))
    for (x, y) in [(6, 6), (s - 8, 6), (6, s - 8), (s - 8, s - 8)]:
        d.rectangle([x, y, x + 1, y + 1], fill=light)
    return im


def glow_dot(d, cx, cy, r, col):
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=shade(col, 0.55))
    d.ellipse([cx - r + 2, cy - r + 2, cx + r - 2, cy + r - 2], fill=col)
    d.ellipse([cx - r + 4, cy - r + 4, cx + r - 4, cy + r - 4], fill=(255, 255, 255, 255))


def save(im, name):
    im.save(OUT + name + ".png")


# ------------------------------------------------------------------ torres
def turret(name, n, base, dark, accent, barrels):
    s = n * 32
    im = Image.new("RGBA", (s, s), T)
    d = ImageDraw.Draw(im)
    c = s // 2
    r = int(s * 0.34)
    # canos apontando para cima
    bw = max(3, int(s * 0.09))
    gap = int(s * 0.14)
    L = int(s * 0.46)
    xs = [c + (i - (barrels - 1) / 2) * (bw + gap) for i in range(barrels)]
    for x in xs:
        x = int(x)
        d.rectangle([x - bw // 2 - 1, c - L - 1, x + bw // 2 + 1, c], fill=dark)
        d.rectangle([x - bw // 2, c - L, x + bw // 2, c], fill=shade(base, 0.9))
        d.rectangle([x - bw // 2, c - L, x + bw // 2, c - L + 2], fill=accent)
    # cabeça
    d.ellipse([c - r - 2, c - r - 2, c + r + 2, c + r + 2], fill=dark)
    d.ellipse([c - r, c - r, c + r, c + r], fill=base)
    d.ellipse([c - r + 3, c - r + 3, c + r - 3, c + r - 3], fill=shade(base, 1.2))
    glow_dot(d, c, c, max(4, r // 2), accent)
    save(im, name)


# ------------------------------------------------------------------ escudos
def shield(name, n, base, dark, glow):
    im = plate(n, base, dark)
    d = ImageDraw.Draw(im)
    s = n * 32
    c = s // 2
    r = int(s * 0.30)
    d.ellipse([c - r - 3, c - r - 3, c + r + 3, c + r + 3], fill=dark)
    d.ellipse([c - r, c - r, c + r, c + r], fill=shade(base, 1.15))
    save(im, name)
    top = Image.new("RGBA", (s, s), T)
    t = ImageDraw.Draw(top)
    rr = int(s * 0.22)
    t.ellipse([c - rr - 2, c - rr - 2, c + rr + 2, c + rr + 2], fill=shade(glow, 0.5))
    t.ellipse([c - rr, c - rr, c + rr, c + rr], fill=glow)
    t.ellipse([c - rr // 2, c - rr // 2, c + rr // 2, c + rr // 2], fill=(255, 255, 255, 255))
    save(top, name + "-top")


# ------------------------------------------------------------------ fábricas / melhoradores
def factory(name, n, base, dark, accent, instant=False, reconstructor=False):
    im = plate(n, base, dark)
    d = ImageDraw.Draw(im)
    s = n * 32
    c = s // 2
    # pista central
    w = int(s * 0.5)
    d.rectangle([c - w // 2 - 2, c - w // 2 - 2, c + w // 2 + 2, c + w // 2 + 2], fill=dark)
    d.rectangle([c - w // 2, c - w // 2, c + w // 2, c + w // 2], fill=shade(base, 0.6))
    if instant:  # listras amarelas = versão instantânea
        for k in range(0, s, 12):
            d.polygon([(k, 4), (k + 6, 4), (k + 2, 10), (k - 4, 10)], fill=YEL)
            d.polygon([(k, s - 5), (k + 6, s - 5), (k + 2, s - 11), (k - 4, s - 11)], fill=YEL)
    save(im, name)

    top = Image.new("RGBA", (s, s), T)
    t = ImageDraw.Draw(top)
    for (x0, y0, x1, y1) in [(c - w // 2, c - w // 2, c - w // 2 + 4, c + w // 2),
                             (c + w // 2 - 4, c - w // 2, c + w // 2, c + w // 2)]:
        t.rectangle([x0, y0, x1, y1], fill=accent)
    save(top, name + "-top")

    # saída (direita): seta/boca
    out = Image.new("RGBA", (s, s), T)
    o = ImageDraw.Draw(out)
    o.rectangle([s - 9, c - w // 2, s - 1, c + w // 2], fill=dark)
    o.polygon([(s - 8, c - 6), (s - 2, c), (s - 8, c + 6)], fill=accent)
    save(out, name + "-out")

    # entrada (esquerda)
    inn = Image.new("RGBA", (s, s), T)
    i = ImageDraw.Draw(inn)
    i.rectangle([0, c - w // 2, 8, c + w // 2], fill=dark)
    i.polygon([(1, c - 6), (7, c), (1, c + 6)], fill=accent)
    save(inn, name + "-in")


# ------------------------------------------------------------------ extras
def wall(name, n):
    im = plate(n, (110, 90, 170, 255), DARK, (170, 150, 230, 255))
    d = ImageDraw.Draw(im)
    s = n * 32
    d.line([8, 8, s - 9, s - 9], fill=DARK, width=2)
    d.line([s - 9, 8, 8, s - 9], fill=DARK, width=2)
    d.rectangle([s // 2 - 3, s // 2 - 3, s // 2 + 3, s // 2 + 3], fill=YEL)
    save(im, name)


def mender(name, n):
    im = plate(n, (70, 120, 92, 255), (28, 52, 42, 255))
    d = ImageDraw.Draw(im)
    s = n * 32
    c = s // 2
    d.rectangle([c - 4, c - 14, c + 4, c + 14], fill=(160, 255, 190, 255))
    d.rectangle([c - 14, c - 4, c + 14, c + 4], fill=(160, 255, 190, 255))
    save(im, name)
    top = Image.new("RGBA", (s, s), T)
    t = ImageDraw.Draw(top)
    t.rectangle([c - 2, c - 10, c + 2, c + 10], fill=(255, 255, 255, 255))
    t.rectangle([c - 10, c - 2, c + 10, c + 2], fill=(255, 255, 255, 255))
    save(top, name + "-top")


def vault(name, n):
    im = plate(n, (92, 78, 140, 255), DARK)
    d = ImageDraw.Draw(im)
    s = n * 32
    c = s // 2
    d.rectangle([10, 10, s - 11, s - 11], outline=DARK, width=3)
    glow_dot(d, c, c, 12, YEL)
    save(im, name)


def node(name, n):
    im = plate(n, (70, 110, 130, 255), (28, 48, 60, 255))
    d = ImageDraw.Draw(im)
    s = n * 32
    c = s // 2
    d.rectangle([c - 3, 6, c + 3, s - 7], fill=(28, 48, 60, 255))
    glow_dot(d, c, c, 9, (120, 255, 255, 255))
    save(im, name)


def battery(name, n):
    im = plate(n, (90, 78, 140, 255), DARK)
    d = ImageDraw.Draw(im)
    s = n * 32
    for k in range(3):
        x = 12 + k * ((s - 28) // 2)
        d.rectangle([x, 10, x + 8, s - 11], fill=DARK)
        d.rectangle([x + 2, 12, x + 6, s - 13], fill=shade(BASE, 0.8))
    save(im, name)
    top = Image.new("RGBA", (s, s), T)
    t = ImageDraw.Draw(top)
    for k in range(3):
        x = 12 + k * ((s - 28) // 2)
        t.rectangle([x + 2, 12, x + 6, s - 13], fill=(255, 255, 255, 255))
    save(top, name + "-top")


def booster(name, n, col):
    im = plate(n, shade(col, 0.8), shade(col, 0.35))
    d = ImageDraw.Draw(im)
    s = n * 32
    c = s // 2
    r = int(s * 0.3)
    d.polygon([(c, c - r), (c + r, c), (c, c + r), (c - r, c)], fill=shade(col, 0.4))
    save(im, name)
    top = Image.new("RGBA", (s, s), T)
    t = ImageDraw.Draw(top)
    r2 = int(s * 0.22)
    t.polygon([(c, c - r2), (c + r2, c), (c, c + r2), (c - r2, c)], fill=YEL)
    save(top, name + "-top")


def main():
    make_conveyor()
    # armas
    turret("metralhadora-eletrica", 1, (150, 90, 80, 255), (55, 30, 34, 255), (255, 170, 70, 255), 2)
    turret("raio-hiper", 2, (140, 80, 110, 255), (50, 26, 44, 255), (255, 120, 220, 255), 1)
    turret("missil-hiper", 3, (120, 100, 90, 255), (46, 36, 34, 255), (255, 90, 60, 255), 3)
    turret("devastador-hiper", 4, (100, 70, 150, 255), (36, 24, 60, 255), (120, 255, 255, 255), 2)
    # escudos
    shield("escudo-pequeno", 2, (56, 92, 120, 255), (24, 44, 64, 255), (110, 240, 255, 255))
    shield("escudo-medio", 3, (60, 80, 140, 255), (26, 36, 72, 255), (130, 190, 255, 255))
    shield("escudo-grande", 4, (84, 70, 150, 255), (36, 28, 76, 255), (200, 150, 255, 255))
    # fábricas e melhoradores de unidades
    G, GD, GA = (70, 120, 92, 255), (28, 52, 42, 255), (120, 255, 170, 255)
    factory("fabrica-universal-de-unidades", 5, G, GD, GA)
    factory("fabrica-universal-instantanea", 5, G, GD, GA, instant=True)
    O, OD, OA = (140, 110, 70, 255), (58, 44, 28, 255), (255, 200, 100, 255)
    factory("melhorador-de-unidades", 5, O, OD, OA)
    factory("melhorador-de-unidades-instantaneo", 5, O, OD, OA, instant=True)
    # extras
    wall("parede-hiper", 2)
    wall("parede-hiper-grande", 3)
    mender("reparador-hiper", 2)
    vault("cofre-hiper", 3)
    # energia, bateria, melhoradores e lança-foguetes
    node("poste-de-energia-global", 2)
    battery("bateria-hiper", 3)
    booster("melhorador-de-maquinas-mega", 3, (150, 90, 190, 255))
    booster("melhorador-de-maquinas-ultra", 4, (200, 120, 90, 255))
    turret("lanca-foguetes-hiper", 4, (130, 100, 80, 255), (50, 36, 30, 255), (255, 170, 60, 255), 3)


main()
