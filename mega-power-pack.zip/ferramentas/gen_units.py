import os
D="/home/claude/mod/content/blocks/"
# (unit, requisitos, tempo) por cadeia
T1=["silicon/10, lead/10"]
chains={
 "dagger":["dagger","mace","fortress","scepter","reign"],
 "nova":["nova","pulsar","quasar","vela","corvus"],
 "crawler":["crawler","atrax","spiroct","arkyid","toxopid"],
 "flare":["flare","horizon","zenith","antumbra","eclipse"],
 "mono":["mono","poly","mega","quad","oct"],
 "risso":["risso","minke","bryde","sei","omura"],
 "retusa":["retusa","oxynoe","cyerce","aegires","navanax"],
}
TIERS=[
 [("silicon",12),("lead",10)],
 [("silicon",35),("titanium",20)],
 [("silicon",90),("titanium",60),("metaglass",20)],
 [("silicon",300),("titanium",180),("plastanium",50),("thorium",30)],
 [("silicon",700),("titanium",450),("plastanium",160),("surge-alloy",80),("thorium",80)],
]
tier_time=[300,500,800,1500,2400]
tier_req=[]
tier_req_inst=[]
for t in TIERS:
    tier_req.append(", ".join("%s/%d"%(i,q) for i,q in t))
    tier_req_inst.append(", ".join("%s/%d"%(i,int(round(q*1.5))) for i,q in t))
def plans(inst):
    out=[]
    for ch in chains.values():
        for t,u in enumerate(ch):
            reqs="\n".join("      "+r.strip() for r in (tier_req_inst if inst else tier_req)[t].split(","))
            out.append("  {\n    unit: %s\n    requirements: [\n%s\n    ]\n    time: %d\n  }"%(u,reqs,1 if inst else tier_time[t]))
    return "plans: [\n"+"\n".join(out)+"\n]\n"
def w(name,txt): open(D+name+".hjson","w",encoding="utf-8").write(txt)

w("fabrica-universal-de-unidades","""type: UnitFactory
name: "Fábrica Universal de Unidades"
description: "Constrói QUALQUER unidade (terrestre, aérea, naval, de suporte), de T1 a T5, com custos reduzidos. Toque no bloco para escolher a unidade."

category: units
size: 5
health: 2400

requirements: [
  titanium/200
  silicon/200
  lead/150
  plastanium/40
]

research: ground-factory

consumes: { power: 8 }
"""+plans(False))
w("fabrica-universal-instantanea","""type: UnitFactory
name: "Fábrica Universal Instantânea"
description: "Igual à Fábrica Universal de Unidades, mas constrói a unidade INSTANTANEAMENTE (limitada só pelos materiais e pela energia). Consome muita energia."

category: units
size: 5
health: 2800

requirements: [
  titanium/300
  silicon/300
  plastanium/80
  surge-alloy/40
]

research: {
  parent: fabrica-universal-de-unidades
  requirements: [
    titanium/200
    silicon/200
    plastanium/40
  ]
}

consumes: { power: 25 }
"""+plans(True))
for inst in (False,True):
    nm="melhorador-de-unidades"+("-instantaneo" if inst else "")
    w(nm,"""type: Reconstructor
name: "%s"
description: "%s"

category: units
size: 5
health: 2600

requirements: [
  titanium/%d
  silicon/%d
  lead/150
  plastanium/%d
%s]

research: %s

constructTime: %d
consumes: { power: %d }
""" % (
 "Melhorador de Unidades Instantâneo" if inst else "Melhorador de Unidades",
 "Igual ao Melhorador de Unidades, mas a evolução é INSTANTÂNEA. Consome muita energia." if inst else "Evolui qualquer unidade para o próximo tier (T1→T2→T3→T4→T5) usando só energia. Coloque o bloco na saída de uma fábrica.",
 300 if inst else 200, 300 if inst else 200, 80 if inst else 40,
 "  surge-alloy/40\n" if inst else "",
 """{
  parent: melhorador-de-unidades
  requirements: [
    titanium/200
    silicon/200
    plastanium/40
  ]
}""" if inst else """{
  parent: fabrica-universal-de-unidades
  requirements: [
    titanium/200
    silicon/200
    plastanium/40
  ]
}""",
 1 if inst else 900,
 40 if inst else 12))

# extras
w("parede-hiper","""type: Wall
name: "Parede Hiper"
description: "Parede super resistente que ainda reflete algumas balas."

category: defense
size: 2
health: 9000

requirements: [
  titanium/24
  silicon/16
  plastanium/8
]

research: titanium-wall-large

chanceDeflect: 12
flashHit: true
""")
w("parede-hiper-grande","""type: Wall
name: "Parede Hiper Grande"
description: "Versão 3x3 da Parede Hiper. Muito resistente e reflete balas."

category: defense
size: 3
health: 22000

requirements: [
  titanium/54
  silicon/36
  plastanium/18
]

research: parede-hiper

chanceDeflect: 14
flashHit: true
""")
w("reparador-hiper","""type: MendProjector
name: "Reparador Hiper"
description: "Cura rapidamente todos os blocos em um grande raio. Usa energia."

category: effect
size: 2
health: 500

requirements: [
  lead/100
  titanium/50
  silicon/60
]

research: mend-projector

reload: 90
range: 200
healPercent: 18
consumes: { power: 2 }
""")
w("cofre-hiper","""type: StorageBlock
name: "Cofre Hiper"
description: "Guarda até 5000 de cada item. Encoste no núcleo para aumentar a capacidade dele."

category: effect
size: 3
health: 1400

requirements: [
  titanium/200
  silicon/100
]

research: vault

itemCapacity: 5000
""")
