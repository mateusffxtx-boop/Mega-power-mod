import math, random
from PIL import Image, ImageDraw, ImageFont, ImageFilter
SP="/home/claude/mod/sprites/"
W,H=1280,720
random.seed(3)
def mix(a,b,t): return tuple(int(a[i]+(b[i]-a[i])*t) for i in range(3))
F=lambda p,s: ImageFont.truetype(p,s)
BOLD="/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
REG="/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed.ttf"

# fundo: gradiente + grade hexagonal + brilhos
bg=Image.new("RGB",(W,H))
d=ImageDraw.Draw(bg)
for y in range(H):
    d.line([0,y,W,y],fill=mix((38,24,78),(8,6,18),y/H))
bg=bg.convert("RGBA")
grid=Image.new("RGBA",(W,H),(0,0,0,0)); g=ImageDraw.Draw(grid)
r=34
for row in range(-1,int(H/(r*1.5))+2):
    for col in range(-1,int(W/(r*1.75))+2):
        cx=col*r*1.75+(r*0.875 if row%2 else 0); cy=row*r*1.5
        pts=[(cx+r*math.cos(math.pi/3*k+math.pi/6),cy+r*math.sin(math.pi/3*k+math.pi/6)) for k in range(6)]
        g.polygon(pts,outline=(150,130,230,34))
bg=Image.alpha_composite(bg,grid)
def glow(cx,cy,rad,col,a):
    L=Image.new("RGBA",(W,H),(0,0,0,0)); ld=ImageDraw.Draw(L)
    for i in range(rad,0,-4):
        ld.ellipse([cx-i,cy-i,cx+i,cy+i],fill=col+(int(a*(1-i/rad)**2),))
    return L
for (x,y,rad,col,a) in [(640,330,520,(140,100,255),150),(180,640,300,(80,200,255),90),(1130,600,320,(255,200,80),90)]:
    bg=Image.alpha_composite(bg,glow(x,y,rad,col,a))
# partículas
pd=ImageDraw.Draw(bg)
for _ in range(120):
    x,y=random.randint(0,W),random.randint(0,H); s=random.choice([1,1,2,3])
    pd.rectangle([x,y,x+s,y+s],fill=(255,240,180,random.randint(60,200)))

def sprite(name,scale):
    im=Image.open(SP+name+".png").convert("RGBA")
    try:
        t=Image.open(SP+name+"-top.png").convert("RGBA"); im=Image.alpha_composite(im,t)
    except Exception: pass
    return im.resize((int(im.width*scale),int(im.height*scale)),Image.NEAREST)
def place(name,scale,cx,cy,shadow=True):
    im=sprite(name,scale)
    if shadow:
        sh=Image.new("RGBA",im.size,(0,0,0,0)); a=im.split()[3]
        sh.paste((0,0,0,140),mask=a); sh=sh.filter(ImageFilter.GaussianBlur(8))
        bg.alpha_composite(sh,(cx-im.width//2+8,cy-im.height//2+14))
    bg.alpha_composite(im,(cx-im.width//2,cy-im.height//2))

# palco: base luminosa
stage=Image.new("RGBA",(W,H),(0,0,0,0)); sd=ImageDraw.Draw(stage)
sd.ellipse([80,500,1200,690],fill=(120,90,220,70)); sd.ellipse([260,555,1020,675],fill=(255,255,255,18))
bg=Image.alpha_composite(bg,stage)

# versão sem texto: só o Beta Hiper em destaque + minérios, com anéis de energia
ring=Image.new("RGBA",(W,H),(0,0,0,0)); rd=ImageDraw.Draw(ring)
for rr,al in [(300,40),(250,60),(200,90)]:
    rd.ellipse([640-rr,380-rr,640+rr,380+rr],outline=(160,255,255,al),width=3)
bg=Image.alpha_composite(bg,ring)
bg=Image.alpha_composite(bg,glow(640,380,260,(160,255,255),120))
place("beta-hiper",14,640,380)
gem_x=[(300,"ouro"),(420,"rubi"),(540,"safira"),(740,"esmeralda"),(860,"obsidiana")]
import math as _m
for x,g_ in [(150,"ouro"),(1130,"obsidiana")]:
    place(g_,5,x,360)
for k,(g_,ang) in enumerate([("ouro",200),("rubi",235),("safira",270),("esmeralda",305),("obsidiana",340)]):
    pass
for k,g_ in enumerate(["ouro","rubi","safira","esmeralda","obsidiana"]):
    place(g_,3,440+k*100,650)
bg=bg.convert("RGB")
bg.save("/mnt/user-data/outputs/capa-mega-power-pack.png")

# ícone quadrado para o mod (icon.png na raiz)
ic=Image.new("RGBA",(256,256),(0,0,0,0)); idr=ImageDraw.Draw(ic)
for y in range(256): idr.line([0,y,256,y],fill=mix((70,46,140),(14,10,34),y/256)+(255,))
ic=Image.alpha_composite(ic,glow(128,128,150,(150,110,255),170)) if False else ic
L=Image.new("RGBA",(256,256),(0,0,0,0)); ld=ImageDraw.Draw(L)
for i in range(130,0,-4): ld.ellipse([128-i,128-i,128+i,128+i],fill=(150,110,255,int(150*(1-i/130)**2)))
ic=Image.alpha_composite(ic,L)
b=sprite("beta-hiper",6); ic.alpha_composite(b,(128-b.width//2,128-b.height//2-8))
ft=F(BOLD,30); idr=ImageDraw.Draw(ic)
t="MEGA POWER"; idr.text(((256-idr.textlength(t,font=ft))/2,8),t,font=ft,fill=(255,224,92),stroke_width=3,stroke_fill=(20,12,40))
t="PACK"; idr.text(((256-idr.textlength(t,font=ft))/2,214),t,font=ft,fill=(160,255,255),stroke_width=3,stroke_fill=(20,12,40))
ic.save("/home/claude/mod/icon.png")
