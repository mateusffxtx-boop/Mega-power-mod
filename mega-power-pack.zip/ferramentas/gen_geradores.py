import sys
sys.path.insert(0,"/home/claude")
import gen_sprites2 as g   # reaproveita funções de desenho (gera os sprites v2 de novo, sem problema)
from PIL import ImageDraw
M="/home/claude/mod/"
def gerador(name,n,base,dark,gl):
    im,d=g.panel(n,base,dark)
    s=n*32; c=s//2
    for k,rr in enumerate([int(s*0.40),int(s*0.31),int(s*0.22)]):
        d.ellipse([c-rr-2,c-rr-2,c+rr+2,c+rr+2],fill=g.darken(dark,0.3))
        d.ellipse([c-rr,c-rr,c+rr,c+rr],fill=g.mix(base,gl,0.25+0.2*k) if k<2 else g.darken(base,0.5))
    g.dome(d,c,c,int(s*0.16),g.mix(base,gl,0.7))
    for (dx,dy) in [(-1,0),(1,0),(0,-1),(0,1)]:
        d.rectangle([c+dx*int(s*0.40)-3,c+dy*int(s*0.40)-3,c+dx*int(s*0.40)+3,c+dy*int(s*0.40)+3],fill=gl)
    g.glow(im,c,c,int(s*0.2),gl,200)
    g.save(im,name)
gerador("gerador-colossal",4,(150,120,60,255),(58,44,20,255),(255,224,92,255))
gerador("gerador-titanico",6,(110,80,170,255),(40,28,76,255),(160,255,255,255))
def w(n,t): open(M+f"content/blocks/{n}.hjson","w",encoding="utf-8").write(t)
w("gerador-colossal",'''type: SolarGenerator
name: "Gerador Colossal"
description: "Gerador gigante e caríssimo: 30 de energia por tick, sem gastar nenhum recurso."

category: power
size: 4
health: 1800

requirements: [
  surge-alloy/200
  phase-fabric/150
  plastanium/150
  thorium/100
  silicon/300
  safira/60
  esmeralda/40
]

research: gerador-super

powerProduction: 30
''')
w("gerador-titanico",'''type: SolarGenerator
name: "Gerador Titânico"
description: "O maior gerador do mod: 120 de energia por tick, sem gastar nenhum recurso. Precisa de minérios raros para ser construído."

category: power
size: 6
health: 4500

requirements: [
  surge-alloy/400
  phase-fabric/300
  plastanium/300
  thorium/200
  silicon/600
  esmeralda/80
  obsidiana/80
]

research: gerador-colossal

powerProduction: 120
''')
