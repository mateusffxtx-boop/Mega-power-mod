import random, math
from PIL import Image, ImageDraw
M="/home/claude/mod/"
SP=M+"sprites/"

def mix(a,b,t): return tuple(int(a[i]+(b[i]-a[i])*t) for i in range(3))+(255,)
def lt(c,t): return mix(c,(255,255,255),t)
def dk(c,t): return mix(c,(0,0,0),t)
def hexc(c): return "%02x%02x%02x"%c[:3]

ORES=[ # id, nome, cor, dureza, custo
 ("ouro","Ouro",(255,210,74),5,1.2),
 ("rubi","Rubi",(232,64,84),6,1.4),
 ("safira","Safira",(70,130,255),7,1.6),
 ("esmeralda","Esmeralda",(60,214,128),8,1.8),
 ("obsidiana","Obsidiana",(150,90,230),9,2.0),
]
# ---------- itens + minérios de chão e de parede
for oid,nome,col,hard,cost in ORES:
    open(M+f"content/items/{oid}.hjson","w",encoding="utf-8").write(f'''name: "{nome}"
description: "Minério raro. Dureza {hard}. Usado para construir brocas, perfuratrizes e geradores avançados."
color: "{hexc(col)}"
hardness: {hard}
cost: {cost}
''')
    open(M+f"content/blocks/minerio-{oid}.hjson","w",encoding="utf-8").write(f'''type: OreBlock
name: "Minério de {nome}"
itemDrop: {oid}
variants: 3
''')
    open(M+f"content/blocks/minerio-parede-{oid}.hjson","w",encoding="utf-8").write(f'''type: OreBlock
name: "Minério de {nome} (parede)"
itemDrop: {oid}
variants: 3
wallOre: true
''')

def gem(col):
    im=Image.new("RGBA",(32,32),(0,0,0,0)); d=ImageDraw.Draw(im)
    d.polygon([(16,3),(26,11),(22,28),(10,28),(6,11)],fill=dk(col,0.55))
    d.polygon([(16,5),(24,12),(20,26),(12,26),(8,12)],fill=col)
    d.polygon([(16,5),(24,12),(16,14),(8,12)],fill=lt(col,0.55))
    d.polygon([(8,12),(16,14),(12,26)],fill=lt(col,0.2))
    d.polygon([(24,12),(16,14),(20,26)],fill=dk(col,0.3))
    d.point((13,9),fill=(255,255,255,255)); d.point((14,8),fill=(255,255,255,255))
    return im
def crystal(d,cx,cy,r,col):
    d.polygon([(cx,cy-r),(cx+r*0.7,cy-r*0.2),(cx+r*0.5,cy+r*0.8),(cx-r*0.5,cy+r*0.8),(cx-r*0.7,cy-r*0.2)],fill=dk(col,0.5))
    d.polygon([(cx,cy-r+1),(cx+r*0.55,cy-r*0.2),(cx+r*0.35,cy+r*0.6),(cx-r*0.35,cy+r*0.6),(cx-r*0.55,cy-r*0.2)],fill=col)
    d.polygon([(cx,cy-r+1),(cx+r*0.55,cy-r*0.2),(cx,cy)],fill=lt(col,0.5))
def ore_variant(col,seed,wall=False):
    rnd=random.Random(seed)
    im=Image.new("RGBA",(32,32),(0,0,0,0)); d=ImageDraw.Draw(im)
    if wall:  # gemas incrustadas na rocha: pedras escuras ao redor
        for _ in range(7):
            x=rnd.randint(4,28); y=rnd.randint(4,28); r=rnd.randint(3,5)
            d.ellipse([x-r,y-r,x+r,y+r],fill=(30,26,40,200))
    for _ in range(rnd.randint(3,5)):
        x=rnd.randint(7,25); y=rnd.randint(7,25); r=rnd.randint(3,6 if wall else 5)
        crystal(d,x,y,r,col)
    return im
for k,(oid,nome,col,hard,cost) in enumerate(ORES):
    gem(col).save(SP+f"{oid}.png")
    for v in range(3):
        ore_variant(col,k*10+v).save(SP+f"minerio-{oid}{v+1}.png")
        ore_variant(col,k*10+v+100,wall=True).save(SP+f"minerio-parede-{oid}{v+1}.png")

# ---------- brocas de chão: uma especializada em cada minério, cada uma com rotor diferente
DR=[ # id, nome, minério, tamanho, drillTime, energia, requisitos, cor, lâminas
 ("broca-nova-1","Broca de Ouro","ouro",2,200,1.0,["copper/80","graphite/60","silicon/60","titanium/30"],(190,160,70),4),
 ("broca-nova-2","Broca de Rubi","rubi",3,130,2.5,["silicon/100","titanium/80","ouro/40","graphite/60"],(200,80,90),3),
 ("broca-nova-3","Broca de Safira","safira",4,90,5,["silicon/150","titanium/150","ouro/60","rubi/40","plastanium/20"],(80,130,230),6),
 ("broca-nova-4","Broca de Esmeralda","esmeralda",5,60,10,["silicon/250","titanium/250","rubi/80","safira/60","plastanium/50"],(60,190,120),8),
 ("broca-nova-5","Broca de Obsidiana","obsidiana",6,40,20,["silicon/400","titanium/400","plastanium/100","safira/100","esmeralda/80","obsidiana/60","surge-alloy/40"],(150,100,220),5),
]
nomes={o[0]:o[1] for o in ORES}
prev="broca-eletrica-grande"
def body(s,col):
    im=Image.new("RGBA",(s,s),(0,0,0,0)); d=ImageDraw.Draw(im)
    d.rectangle([0,0,s-1,s-1],fill=dk(col,0.75)); d.rectangle([1,1,s-2,s-2],fill=dk(col,0.55))
    for y in range(3,s-3): d.line([3,y,s-4,y],fill=mix(lt(col,0.15),dk(col,0.35),(y-3)/max(1,s-6)))
    d.line([3,3,s-4,3],fill=lt(col,0.55)); d.line([3,3,3,s-4],fill=lt(col,0.4))
    d.line([3,s-4,s-4,s-4],fill=dk(col,0.6)); d.line([s-4,3,s-4,s-4],fill=dk(col,0.5))
    for (x,y) in [(7,7),(s-8,7),(7,s-8),(s-8,s-8)]:
        d.rectangle([x-1,y-1,x+1,y+1],fill=dk(col,0.6)); d.point((x-1,y-1),fill=lt(col,0.7))
    return im,d
for (did,nome,oid,size,dt,pw,req,col,blades) in DR:
    reqtxt="\n".join("  "+r for r in req)
    open(M+f"content/blocks/{did}.hjson","w",encoding="utf-8").write(f'''type: Drill
name: "{nome}"
description: "Broca elétrica especializada em {nomes[oid]}: extrai esse minério 3x mais rápido. Também mineira qualquer outro minério. Usa muita energia."

category: production
size: {size}
health: {size*size*90}

requirements: [
{reqtxt}
]

research: {prev}

tier: 12
drillTime: {dt}
consumes: {{ power: {pw} }}
''')
    prev=did
    s=size*32; c=s//2; r=int(s*0.36)
    im,d=body(s,col)
    d.ellipse([c-r-2,c-r-2,c+r+2,c+r+2],fill=dk(col,0.7)); d.ellipse([c-r,c-r,c+r,c+r],fill=dk(col,0.78))
    im.save(SP+f"{did}.png")
    rot=Image.new("RGBA",(s,s),(0,0,0,0)); rd=ImageDraw.Draw(rot)
    L=int(s*0.34); w=max(2,int(s*(0.075 if blades<6 else 0.045)))
    for k in range(blades):
        a=k*2*math.pi/blades
        dx,dy=math.cos(a),math.sin(a); px,py=-dy,dx
        if did=="broca-nova-5":  # lâminas curvas (espiral)
            pts=[(c+px*w,c+py*w),(c+dx*L+px*w+dy*-6,c+dy*L+py*w+dx*6),(c+dx*L-px*w+dy*-6,c+dy*L-py*w+dx*6),(c-px*w,c-py*w)]
        else:
            pts=[(c+px*w,c+py*w),(c+dx*L+px*w,c+dy*L+py*w),(c+dx*L-px*w,c+dy*L-py*w),(c-px*w,c-py*w)]
        rd.polygon(pts,fill=lt(col,0.25))
        rd.line([(c+dx*3,c+dy*3),(c+dx*L,c+dy*L)],fill=lt(col,0.7))
    if did in ("broca-nova-4","broca-nova-5"):
        rd.ellipse([c-L-2,c-L-2,c+L+2,c+L+2],outline=lt(col,0.3))
    rd.ellipse([c-w-2,c-w-2,c+w+2,c+w+2],fill=dk(col,0.4))
    rot.save(SP+f"{did}-rotator.png")
    top=Image.new("RGBA",(s,s),(0,0,0,0)); td=ImageDraw.Draw(top)
    td.ellipse([c-5,c-5,c+5,c+5],fill=lt(col,0.35)); td.ellipse([c-3,c-3,c+3,c+3],fill=(255,255,255,255))
    top.save(SP+f"{did}-top.png")

# ---------- perfuratrizes de parede (BeamDrill): uma por minério
WD=[ # id, nome, minério, tamanho, drillTime, alcance, energia, requisitos, cor
 ("perfuratriz-1","Perfuratriz de Ouro","ouro",2,220,6,3,["silicon/80","titanium/60","graphite/60","ouro/30"],(190,160,70)),
 ("perfuratriz-2","Perfuratriz de Rubi","rubi",3,150,8,6,["silicon/120","titanium/100","ouro/50","rubi/30"],(200,80,90)),
 ("perfuratriz-3","Perfuratriz de Safira","safira",4,110,10,12,["silicon/180","titanium/160","rubi/50","safira/40","plastanium/20"],(80,130,230)),
 ("perfuratriz-4","Perfuratriz de Esmeralda","esmeralda",4,80,12,22,["silicon/260","titanium/240","safira/60","esmeralda/50","plastanium/50"],(60,190,120)),
 ("perfuratriz-5","Perfuratriz de Obsidiana","obsidiana",5,55,14,40,["silicon/400","titanium/380","plastanium/100","esmeralda/70","obsidiana/60","surge-alloy/40"],(150,100,220)),
]
prev="broca-nova-1"
for (did,nome,oid,size,dt,rng,pw,req,col) in WD:
    reqtxt="\n".join("  "+r for r in req)
    open(M+f"content/blocks/{did}.hjson","w",encoding="utf-8").write(f'''type: BeamDrill
name: "{nome}"
description: "Perfura PAREDES com um feixe de {rng} blocos de alcance. Especializada em {nomes[oid]}: 3x mais rápida nesse minério da parede. Consome muita energia."

category: production
size: {size}
health: {size*size*100}

requirements: [
{reqtxt}
]

research: {prev}

tier: 12
drillTime: {dt}
range: {rng}
consumes: {{ power: {pw} }}
''')
    prev=did
    s=size*32; c=s//2
    im,d=body(s,dk(col,0.1))
    # tampa quadrada central (a perfuratriz gira, o topo aponta para a direita)
    d.rectangle([c-10,c-10,c+10,c+10],fill=dk(col,0.75))
    d.rectangle([c-8,c-8,c+8,c+8],fill=dk(col,0.5))
    im.save(SP+f"{did}.png")
    top=Image.new("RGBA",(s,s),(0,0,0,0)); td=ImageDraw.Draw(top)
    td.rectangle([c-12,c-9,s-3,c+9],fill=dk(col,0.65))            # canhão apontando para a direita
    td.rectangle([c-10,c-7,s-5,c+7],fill=lt(col,0.1))
    td.rectangle([s-9,c-5,s-3,c+5],fill=dk(col,0.8))
    td.rectangle([s-7,c-3,s-3,c+3],fill=lt(col,0.7))
    td.ellipse([c-9,c-9,c+9,c+9],fill=dk(col,0.55)); td.ellipse([c-5,c-5,c+5,c+5],fill=lt(col,0.5)); td.ellipse([c-2,c-2,c+2,c+2],fill=(255,255,255,255))
    top.save(SP+f"{did}-top.png")
