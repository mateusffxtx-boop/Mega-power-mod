from PIL import Image, ImageDraw

OUT = "/home/claude/mod/sprites/"
T = (0, 0, 0, 0)


def mix(a, b, t):
    t = max(0.0, min(1.0, t))
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3)) + (255,)


def lighten(c, t):
    return mix(c, (255, 255, 255), t)


def darken(c, t):
    return mix(c, (0, 0, 0), t)


def canvas(w, h=None):
    return Image.new("RGBA", (w, h or w), T)


def save(im, name):
    im.save(OUT + name + ".png")


def vgrad(d, box, c1, c2):
    x0, y0, x1, y1 = box
    h = y1 - y0
    for i in range(h + 1):
        d.line([x0, y0 + i, x1, y0 + i], fill=mix(c1, c2, i / max(1, h)))


def bolt(d, x, y, base):
    d.rectangle([x - 1, y - 1, x + 1, y + 1], fill=darken(base, 0.55))
    d.point((x - 1, y - 1), fill=lighten(base, 0.7))


def panel(n, base, dark, seams=True):
    s = n * 32
    im = canvas(s)
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, s - 1, s - 1], fill=darken(dark, 0.3))
    d.rectangle([1, 1, s - 2, s - 2], fill=dark)
    vgrad(d, [3, 3, s - 4, s - 4], lighten(base, 0.2), darken(base, 0.2))
    d.line([3, 3, s - 4, 3], fill=lighten(base, 0.5))
    d.line([3, 3, 3, s - 4], fill=lighten(base, 0.35))
    d.line([3, s - 4, s - 4, s - 4], fill=darken(base, 0.5))
    d.line([s - 4, 3, s - 4, s - 4], fill=darken(base, 0.4))
    if seams:
        for k in range(1, n):
            p = k * 32
            d.line([p, 3, p, s - 4], fill=darken(base, 0.45))
            d.line([p + 1, 3, p + 1, s - 4], fill=lighten(base, 0.25))
            d.line([3, p, s - 4, p], fill=darken(base, 0.45))
            d.line([3, p + 1, s - 4, p + 1], fill=lighten(base, 0.25))
    for (x, y) in [(7, 7), (s - 8, 7), (7, s - 8), (s - 8, s - 8)]:
        bolt(d, x, y, base)
    return im, d


def dome(d, cx, cy, r, col):
    for i in range(r, 0, -1):
        t = 1 - i / r
        d.ellipse([cx - i, cy - i, cx + i, cy + i], fill=mix(darken(col, 0.5), lighten(col, 0.5), t ** 1.1))
    hr = max(1, r // 4)
    d.ellipse([cx - r // 2, cy - r // 2 - 1, cx - r // 2 + hr * 2, cy - r // 2 + hr * 2 - 1], fill=lighten(col, 0.75))


def glow(im, cx, cy, r, col, alpha=170):
    layer = canvas(im.width, im.height)
    ld = ImageDraw.Draw(layer)
    for i in range(r, 0, -1):
        a = int(alpha * (1 - i / r) ** 1.5) + 10
        ld.ellipse([cx - i, cy - i, cx + i, cy + i], fill=col[:3] + (min(255, a),))
    im.alpha_composite(layer)


def outline(im, col):
    """contorno escuro de 1px ao redor dos pixels opacos"""
    w, h = im.size
    src = im.copy()
    px = src.load()
    out = im.load()
    for y in range(h):
        for x in range(w):
            if px[x, y][3] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < w and 0 <= ny < h and px[nx, ny][3] > 200:
                        out[x, y] = col
                        break
    return im


# --------------------------------------------------------------- torres (cano para cima)
def barrel(d, x, c, L, bw, base, dark, accent):
    d.rectangle([x - bw // 2 - 1, c - L - 1, x + bw // 2 + 1, c], fill=darken(dark, 0.3))
    for k in range(bw + 1):
        d.line([x - bw // 2 + k, c - L, x - bw // 2 + k, c], fill=mix(lighten(base, 0.4), darken(base, 0.45), k / bw))
    d.rectangle([x - bw // 2 - 2, c - L - 3, x + bw // 2 + 2, c - L + 3], fill=dark)
    d.rectangle([x - bw // 2, c - L - 2, x + bw // 2, c - L], fill=accent)
    for y in range(c - L + 8, c - 4, 9):
        d.line([x - bw // 2, y, x + bw // 2, y], fill=darken(base, 0.55))


def turret(name, n, base, dark, accent, tubes):
    s = n * 32
    im = canvas(s)
    d = ImageDraw.Draw(im)
    c = s // 2
    bw = max(5, int(s * 0.10))
    L = int(s * 0.50)
    spacing = int(s * 0.17) + bw
    for i in range(tubes):
        barrel(d, c + int((i - (tubes - 1) / 2) * spacing), c, L, bw, base, dark, accent)
    r = int(s * 0.36)
    d.ellipse([c - r - 2, c - r - 2, c + r + 2, c + r + 2], fill=darken(dark, 0.3))
    dome(d, c, c, r, base)
    pw = max(4, int(s * 0.07))
    for sx in (-1, 1):
        x0 = c + sx * (r - pw)
        d.rectangle([min(x0, x0 + sx * pw), c - int(r * .5), max(x0, x0 + sx * pw), c + int(r * .55)], fill=dark)
        d.rectangle([min(x0, x0 + sx * pw) + 1, c - int(r * .5) + 1, max(x0, x0 + sx * pw) - 1, c + int(r * .55) - 1], fill=darken(base, 0.25))
    glow(im, c, c + int(r * .25), max(5, r // 2 + 2), accent, 220)
    d = ImageDraw.Draw(im)
    d.ellipse([c - 2, c + int(r * .25) - 2, c + 2, c + int(r * .25) + 2], fill=(255, 255, 255, 255))
    save(outline(im, darken(dark, 0.4)), name)


def rocket_launcher(name, n):
    s = n * 32
    im = canvas(s)
    d = ImageDraw.Draw(im)
    c = s // 2
    base, dark, acc = (132, 104, 84, 255), (46, 34, 28, 255), (255, 176, 64, 255)
    # corpo
    d.rectangle([10, 22, s - 11, s - 12], fill=darken(dark, 0.3))
    vgrad(d, [12, 24, s - 13, s - 14], lighten(base, 0.2), darken(base, 0.3))
    # 5 tubos de foguete
    tw = 16
    gap = (s - 24 - tw * 5) // 4
    for i in range(5):
        x0 = 12 + i * (tw + gap)
        d.rectangle([x0 - 1, 6, x0 + tw, s - 40], fill=darken(dark, 0.2))
        for k in range(tw):
            d.line([x0 + k, 8, x0 + k, s - 42], fill=mix(lighten(base, 0.35), darken(base, 0.5), k / tw))
        d.rectangle([x0 - 1, 6, x0 + tw, 14], fill=dark)
        d.ellipse([x0 + 2, 5, x0 + tw - 2, 17], fill=(20, 14, 12, 255))
        d.ellipse([x0 + 5, 8, x0 + tw - 5, 14], fill=acc)
        d.line([x0 + 2, 34, x0 + tw - 2, 34], fill=dark)
        d.line([x0 + 2, 48, x0 + tw - 2, 48], fill=dark)
    # cúpula traseira
    r = 24
    d.ellipse([c - r - 2, s - 62, c + r + 2, s - 62 + 2 * r + 4], fill=darken(dark, 0.3))
    dome(d, c, s - 62 + r + 2, r, base)
    glow(im, c, s - 38, 14, acc, 230)
    d = ImageDraw.Draw(im)
    d.ellipse([c - 3, s - 41, c + 3, s - 35], fill=(255, 255, 255, 255))
    save(outline(im, darken(dark, 0.4)), name)


# --------------------------------------------------------------- escudos
def shield(name, n, base, dark, gl):
    im, d = panel(n, base, dark)
    s = n * 32
    c = s // 2
    r = int(s * 0.34)
    d.ellipse([c - r - 3, c - r - 3, c + r + 3, c + r + 3], fill=darken(dark, 0.3))
    d.ellipse([c - r, c - r, c + r, c + r], fill=dark)
    d.ellipse([c - r + 3, c - r + 3, c + r - 3, c + r - 3], fill=darken(base, 0.3))
    for (dx, dy) in [(-1, -1), (1, -1), (-1, 1), (1, 1)]:
        px, py = c + dx * (r + 1), c + dy * (r + 1)
        d.rectangle([px - 3, py - 3, px + 3, py + 3], fill=lighten(base, 0.2))
        d.rectangle([px - 1, py - 1, px + 1, py + 1], fill=gl)
    dome(d, c, c, int(r * 0.6), mix(base, gl, 0.45))
    save(im, name)
    top = canvas(s)
    glow(top, c, c, int(s * 0.34), gl, 150)
    td = ImageDraw.Draw(top)
    rr = int(s * 0.17)
    td.ellipse([c - rr, c - rr, c + rr, c + rr], fill=gl)
    td.ellipse([c - rr // 2, c - rr // 2, c + rr // 2, c + rr // 2], fill=(255, 255, 255, 255))
    save(top, name + "-top")


# --------------------------------------------------------------- fábricas
def hazard(d, box, col1, col2, vertical=False):
    x0, y0, x1, y1 = box
    d.rectangle(box, fill=col2)
    step = 8
    if not vertical:
        for k in range(x0 - (y1 - y0), x1 + 1, step * 2):
            d.polygon([(k, y1), (k + step, y1), (k + step + (y1 - y0), y0), (k + (y1 - y0), y0)], fill=col1)
    # recorta fora da caixa
    return


def factory(name, n, base, dark, acc, instant=False):
    im, d = panel(n, base, dark, seams=False)
    s = n * 32
    c = s // 2
    bay = int(s * 0.52)
    d.rectangle([c - bay // 2 - 3, c - bay // 2 - 3, c + bay // 2 + 3, c + bay // 2 + 3], fill=darken(dark, 0.3))
    vgrad(d, [c - bay // 2, c - bay // 2, c + bay // 2, c + bay // 2], darken(base, 0.55), darken(base, 0.75))
    for k in range(c - bay // 2 + 6, c + bay // 2, 8):
        d.line([k, c - bay // 2, k, c + bay // 2], fill=darken(base, 0.8))
    for k in range(c - bay // 2 + 6, c + bay // 2, 8):
        d.line([c - bay // 2, k, c + bay // 2, k], fill=darken(base, 0.8))
    if instant:  # faixa de aviso amarela/preta = versão instantânea
        band = Image.new("RGBA", (s - 12, 7), T)
        bd = ImageDraw.Draw(band)
        bd.rectangle([0, 0, s, 7], fill=(36, 30, 20, 255))
        for k in range(-8, s, 12):
            bd.polygon([(k, 7), (k + 6, 7), (k + 13, 0), (k + 7, 0)], fill=(255, 224, 92, 255))
        im.paste(band, (6, 6))
        im.paste(band.transpose(Image.FLIP_TOP_BOTTOM), (6, s - 13))
    else:
        for i in range(3):
            d.rectangle([10 + i * 7, 8, 14 + i * 7, 10], fill=acc)
    save(im, name)

    top = canvas(s)
    t = ImageDraw.Draw(top)
    for (x0, y0, x1, y1) in [(c - bay // 2 - 4, c - bay // 2 - 4, c - bay // 2 + 5, c - bay // 2 + 5),
                             (c + bay // 2 - 5, c - bay // 2 - 4, c + bay // 2 + 4, c - bay // 2 + 5),
                             (c - bay // 2 - 4, c + bay // 2 - 5, c - bay // 2 + 5, c + bay // 2 + 4),
                             (c + bay // 2 - 5, c + bay // 2 - 5, c + bay // 2 + 4, c + bay // 2 + 4)]:
        t.rectangle([x0, y0, x1, y1], fill=darken(base, 0.1))
        t.rectangle([x0 + 2, y0 + 2, x1 - 2, y1 - 2], fill=acc)
    save(top, name + "-top")

    out = canvas(s)
    o = ImageDraw.Draw(out)
    o.rectangle([s - 10, c - bay // 2, s - 1, c + bay // 2], fill=darken(dark, 0.2))
    for k in range(3):
        x = s - 9 + k * 3
        o.polygon([(x, c - 8), (x + 3, c), (x, c + 8), (x - 1, c + 8), (x + 2, c), (x - 1, c - 8)], fill=acc)
    save(out, name + "-out")

    inn = canvas(s)
    i = ImageDraw.Draw(inn)
    i.rectangle([0, c - bay // 2, 9, c + bay // 2], fill=darken(dark, 0.2))
    for k in range(3):
        x = 1 + k * 3
        i.polygon([(x, c - 8), (x + 3, c), (x, c + 8), (x - 1, c + 8), (x + 2, c), (x - 1, c - 8)], fill=acc)
    save(inn, name + "-in")


# --------------------------------------------------------------- energia
def node(name, n):
    base, dark, gl = (66, 108, 132, 255), (24, 44, 58, 255), (120, 255, 255, 255)
    im, d = panel(n, base, dark)
    s = n * 32
    c = s // 2
    d.rectangle([c - 4, 8, c + 4, s - 9], fill=darken(dark, 0.2))
    vgrad(d, [c - 3, 9, c + 3, s - 10], lighten(base, 0.3), darken(base, 0.4))
    for k, rr in enumerate([20, 14, 8]):
        d.ellipse([c - rr, c - rr, c + rr, c + rr], outline=mix(base, gl, 0.3 + k * 0.2))
    dome(d, c, c, 8, mix(base, gl, 0.6))
    glow(im, c, c, 14, gl, 200)
    save(im, name)


def battery(name, n):
    base, dark = (92, 78, 146, 255), (36, 28, 72, 255)
    im, d = panel(n, base, dark)
    s = n * 32
    cells = 4
    w = (s - 24) // cells
    for k in range(cells):
        x0 = 12 + k * w
        d.rectangle([x0, 14, x0 + w - 4, s - 15], fill=darken(dark, 0.3))
        d.rectangle([x0 + 1, 15, x0 + w - 5, s - 16], fill=darken(base, 0.5))
        d.rectangle([x0 + w // 2 - 3, 10, x0 + w // 2 - 1, 13], fill=(255, 224, 92, 255))
    save(im, name)
    top = canvas(s)
    t = ImageDraw.Draw(top)
    for k in range(cells):
        x0 = 12 + k * w
        t.rectangle([x0 + 2, 17, x0 + w - 6, s - 18], fill=(255, 255, 255, 255))
        for yy in range(20, s - 18, 6):
            t.line([x0 + 2, yy, x0 + w - 6, yy], fill=(0, 0, 0, 70))
    save(top, name + "-top")


def booster(name, n, col):
    base, dark = darken(col, 0.15), darken(col, 0.6)
    im, d = panel(n, base, dark)
    s = n * 32
    c = s // 2
    r = int(s * 0.32)
    d.polygon([(c, c - r - 3), (c + r + 3, c), (c, c + r + 3), (c - r - 3, c)], fill=darken(dark, 0.3))
    d.polygon([(c, c - r), (c + r, c), (c, c + r), (c - r, c)], fill=darken(base, 0.45))
    for i in range(n * 2):
        d.polygon([(c, c - r + i * 3 + 2), (c + r - i * 3 - 2, c), (c, c + r - i * 3 - 2), (c - r + i * 3 + 2, c)], outline=lighten(col, 0.1 * i))
    save(im, name)
    top = canvas(s)
    glow(top, c, c, int(r * 1.1), (255, 224, 92, 255), 150)
    t = ImageDraw.Draw(top)
    r2 = int(r * 0.55)
    t.polygon([(c, c - r2), (c + r2, c), (c, c + r2), (c - r2, c)], fill=(255, 224, 92, 255))
    t.polygon([(c, c - r2 // 2), (c + r2 // 2, c), (c, c + r2 // 2), (c - r2 // 2, c)], fill=(255, 255, 255, 255))
    save(top, name + "-top")


# --------------------------------------------------------------- extras
def wall(name, n):
    base, dark = (112, 92, 172, 255), (40, 28, 74, 255)
    im, d = panel(n, base, dark, seams=False)
    s = n * 32
    d.line([8, 8, s - 9, s - 9], fill=darken(base, 0.5), width=3)
    d.line([s - 9, 8, 8, s - 9], fill=darken(base, 0.5), width=3)
    d.line([8, 10, s - 11, s - 9], fill=lighten(base, 0.3))
    d.line([s - 9, 10, 10, s - 9], fill=lighten(base, 0.3))
    c = s // 2
    d.rectangle([c - 6, c - 6, c + 6, c + 6], fill=dark)
    dome(d, c, c, 5, (255, 224, 92, 255))
    save(im, name)


def mender(name, n):
    base, dark = (66, 124, 92, 255), (24, 52, 40, 255)
    im, d = panel(n, base, dark)
    s = n * 32
    c = s // 2
    d.rectangle([c - 7, c - 17, c + 7, c + 17], fill=darken(dark, 0.2))
    d.rectangle([c - 17, c - 7, c + 17, c + 7], fill=darken(dark, 0.2))
    d.rectangle([c - 5, c - 15, c + 5, c + 15], fill=(150, 255, 190, 255))
    d.rectangle([c - 15, c - 5, c + 15, c + 5], fill=(150, 255, 190, 255))
    d.rectangle([c - 3, c - 13, c - 2, c + 13], fill=(220, 255, 235, 255))
    save(im, name)
    top = canvas(s)
    glow(top, c, c, 16, (150, 255, 190, 255), 150)
    save(top, name + "-top")


def vault(name, n):
    base, dark = (94, 80, 144, 255), (36, 28, 70, 255)
    im, d = panel(n, base, dark)
    s = n * 32
    c = s // 2
    d.rectangle([11, 11, s - 12, s - 12], fill=darken(dark, 0.2))
    vgrad(d, [13, 13, s - 14, s - 14], lighten(base, 0.1), darken(base, 0.35))
    r = 16
    d.ellipse([c - r - 2, c - r - 2, c + r + 2, c + r + 2], fill=dark)
    dome(d, c, c, r, mix(base, (255, 224, 92, 255), 0.2))
    for ang in range(4):
        if ang % 2 == 0:
            d.rectangle([c - 2, c - r - 4, c + 2, c + r + 4], fill=(255, 224, 92, 255)) if ang == 0 else d.rectangle([c - r - 4, c - 2, c + r + 4, c + 2], fill=(255, 224, 92, 255))
    dome(d, c, c, 5, (255, 224, 92, 255))
    save(im, name)


# --------------------------------------------------------------- unidade do jogador
def beta_hiper():
    D, B, Lc, Y = (40, 28, 74, 255), (104, 86, 158, 255), (160, 140, 220, 255), (255, 224, 92, 255)
    im = canvas(32)
    d = ImageDraw.Draw(im)
    d.polygon([(16, 1), (20, 12), (30, 24), (30, 28), (21, 25), (16, 30), (11, 25), (2, 28), (2, 24), (12, 12)], fill=D)
    d.polygon([(16, 3), (19, 13), (28, 24), (20, 23), (16, 27), (12, 23), (4, 24), (13, 13)], fill=B)
    d.polygon([(16, 3), (19, 13), (16, 17), (13, 13)], fill=Lc)
    d.polygon([(16, 6), (18, 12), (16, 15), (14, 12)], fill=(120, 240, 255, 255))
    d.line([(7, 24), (13, 14)], fill=darken(B, 0.4))
    d.line([(25, 24), (19, 14)], fill=darken(B, 0.4))
    d.rectangle([14, 24, 17, 27], fill=Y)
    d.point((4, 26), fill=Y)
    d.point((27, 26), fill=Y)
    save(outline(im, (24, 16, 48, 255)), "beta-hiper")
    c = canvas(32)
    cd = ImageDraw.Draw(c)
    cd.ellipse([13, 17, 18, 22], fill=Y)
    save(c, "beta-hiper-cell")


def main():
    turret("metralhadora-eletrica", 1, (156, 96, 84, 255), (54, 30, 34, 255), (255, 176, 74, 255), 2)
    turret("raio-hiper", 2, (146, 84, 118, 255), (50, 26, 44, 255), (255, 124, 224, 255), 1)
    turret("missil-hiper", 3, (124, 104, 94, 255), (44, 36, 34, 255), (255, 96, 64, 255), 3)
    turret("devastador-hiper", 4, (104, 74, 156, 255), (34, 24, 60, 255), (120, 255, 255, 255), 2)
    rocket_launcher("lanca-foguetes-hiper", 4)
    shield("escudo-pequeno", 2, (58, 96, 124, 255), (22, 42, 62, 255), (110, 240, 255, 255))
    shield("escudo-medio", 3, (62, 84, 146, 255), (24, 34, 72, 255), (130, 190, 255, 255))
    shield("escudo-grande", 4, (88, 72, 156, 255), (34, 26, 76, 255), (205, 150, 255, 255))
    G, GD, GA = (72, 124, 96, 255), (26, 52, 42, 255), (120, 255, 170, 255)
    O, OD, OA = (146, 114, 72, 255), (58, 44, 28, 255), (255, 200, 100, 255)
    factory("fabrica-universal-de-unidades", 5, G, GD, GA)
    factory("fabrica-universal-instantanea", 5, G, GD, GA, instant=True)
    factory("melhorador-de-unidades", 5, O, OD, OA)
    factory("melhorador-de-unidades-instantaneo", 5, O, OD, OA, instant=True)
    node("poste-de-energia-global", 2)
    battery("bateria-hiper", 3)
    booster("melhorador-de-maquinas-mega", 3, (150, 90, 190, 255))
    booster("melhorador-de-maquinas-ultra", 4, (214, 120, 90, 255))
    wall("parede-hiper", 2)
    wall("parede-hiper-grande", 3)
    mender("reparador-hiper", 2)
    vault("cofre-hiper", 3)
    beta_hiper()


main()
