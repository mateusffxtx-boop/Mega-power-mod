# Deixa TODAS as máquinas difíceis: custo x3, consumo de energia x3, pesquisa 4x mais cara.
# Roda uma vez por arquivo (marcador na primeira linha). Rode DEPOIS dos outros geradores.
import re, glob, os
MARK="# dificuldade-v1 (custo x3, energia x3, pesquisa x4)"
n=0
for p in sorted(glob.glob("/home/claude/mod/content/blocks/*.hjson")):
    s=open(p,encoding="utf-8").read()
    if s.startswith(MARK) or s.startswith("type: OreBlock"): continue
    # custos do bloco (apenas o bloco 'requirements' sem indentação)
    def req(m):
        body=re.sub(r"^([ \t]+)([a-z\-]+)/(\d+)[ \t]*$",lambda k:"%s%s/%d"%(k.group(1),k.group(2),int(k.group(3))*3),m.group(2),flags=re.M)
        return m.group(1)+body+m.group(3)
    s=re.sub(r"(^requirements: \[\n)(.*?)(^\])",req,s,count=1,flags=re.M|re.S)
    # energia consumida
    s=re.sub(r"^consumes: \{ power: ([0-9.]+) \}",lambda m:"consumes: { power: %s }"%(("%g"%round(float(m.group(1))*3,2))),s,flags=re.M)
    s=s.rstrip("\n")+"\n\nresearchCostMultiplier: 4\n"
    open(p,"w",encoding="utf-8").write(MARK+"\n"+s); n+=1
print("arquivos ajustados:",n)
