// Mega Power Pack - Fabricador Universal (escolha o item)
// Entradas: qualquer mistura de itens baratos. Saída: o item escolhido.

const MOD = "mega-power-pack-";

// Executa fn quando o conteúdo estiver pronto: no jogo normal, no host (LAN) e em servidor dedicado (sem tela).
function aoCarregar(fn){
  if(typeof ContentInitEvent !== "undefined"){
    Events.on(ContentInitEvent, fn);
  }else{
    let feito = false;
    const rodar = () => { if(!feito){ feito = true; fn(); } };
    Events.on(ClientLoadEvent, rodar);
    if(typeof ServerLoadEvent !== "undefined") Events.on(ServerLoadEvent, rodar);
  }
}


// Itens baratos aceitos como entrada (valem 1 cada, em qualquer mistura)
const ENTRADAS = ["copper", "lead", "sand", "coal", "scrap"];

// Custo (em itens baratos) para fabricar 1 unidade de cada item. Edite à vontade!
const CUSTO = {
  "copper": 1, "lead": 1, "sand": 1, "coal": 1, "scrap": 1,
  "metaglass": 3, "graphite": 3, "silicon": 4, "titanium": 4, "spore-pod": 3,
  "thorium": 6, "pyratite": 6, "blast-compound": 8, "plastanium": 8,
  "phase-fabric": 10, "surge-alloy": 12
};

// Escolha de cada fabricador, guardada por posição no mapa
const ESCOLHA = {};
function lerSel(build){ return ESCOLHA[build.pos()] || null; }
function gravarSel(build, i){ if(i == null) delete ESCOLHA[build.pos()]; else ESCOLHA[build.pos()] = i; }

function item(nome){
  return Vars.content.getByName(ContentType.item, nome);
}

function aplicar(nome, ciclo, porCiclo){
  const b = Vars.content.getByName(ContentType.block, MOD + nome);
  if(b == null) return;

  const entradas = [];
  ENTRADAS.forEach(n => { const i = item(n); if(i != null) entradas.push(i); });
  const saidas = [];
  Object.keys(CUSTO).forEach(n => { const i = item(n); if(i != null) saidas.push(i); });

  b.configurable = true;
  b.saveConfig = true;
  b.clearOnDoubleTap = true;
  b.update = true;
  b.solid = true;
  b.hasItems = true;
  b.hasPower = true;
  try{ b.acceptsItems = true; }catch(e){}

  b.config(Item, (build, i) => {
    gravarSel(build, i);
    build.progress = 0;
  });
  b.configClear(build => {
    gravarSel(build, null);
    build.progress = 0;
  });

  b.buildType = () => extend(GenericCrafter.GenericCrafterBuild, b, {
    dumpT: 0,

    created(){
      this.super$created();
      gravarSel(this, null); // se vier de um save/servidor, read() aplica a escolha logo depois
    },

    onRemoved(){
      gravarSel(this, null);
      this.super$onRemoved();
    },

    // aceita só os itens baratos (e nunca o item que está sendo produzido)
    acceptItem(source, it){
      return entradas.indexOf(it) != -1 && it != lerSel(this) && this.items.get(it) < this.getMaximumAccepted(it);
    },

    getMaximumAccepted(it){
      return this.block.itemCapacity;
    },

    shouldConsume(){
      return lerSel(this) != null && this.items.get(lerSel(this)) < this.block.itemCapacity && this.enabled;
    },

    material(){
      let total = 0;
      for(let k = 0; k < entradas.length; k++){
        if(entradas[k] != lerSel(this)) total += this.items.get(entradas[k]);
      }
      return total;
    },

    gastar(qtd){
      // gasta sempre do item mais abundante
      while(qtd > 0){
        var melhor = null, mq = 0;
        for(let k = 0; k < entradas.length; k++){
          var e = entradas[k];
          if(e == lerSel(this)) continue;
          var q = this.items.get(e);
          if(q > mq){ mq = q; melhor = e; }
        }
        if(melhor == null) return;
        this.items.remove(melhor, 1);
        qtd--;
      }
    },

    updateTile(){
      const alvo = lerSel(this);
      const ativo = alvo != null && this.shouldConsume() && this.efficiency > 0;

      if(ativo){
        const custo = CUSTO[alvo.name] || 1;
        this.progress += this.edelta() / ciclo;
        let feitos = 0;
        while(this.progress >= 1 && feitos < porCiclo){
          if(this.material() < custo || this.items.get(alvo) >= this.block.itemCapacity){
            this.progress = Math.min(this.progress, 1);
            break;
          }
          this.gastar(custo);
          this.items.add(alvo, 1);
          this.progress -= 1;
          feitos++;
        }
      }else{
        this.progress = 0;
      }

      this.warmup = Mathf.approachDelta(this.warmup, ativo ? 1 : 0, 0.025);
      this.totalProgress += this.warmup * Time.delta;

      if(alvo != null && this.items.get(alvo) > 0){
        this.dumpT += this.delta();
        if(this.dumpT >= (porCiclo > 1 ? 1 : 5)){
          this.dumpT = 0;
          this.dump(alvo);
        }
      }
    },

    buildConfiguration(table){
      const self = this;
      const cont = new Table();
      const grupo = new ButtonGroup();
      grupo.setMinCheckCount(0);
      grupo.setMaxCheckCount(1);
      let n = 0;
      saidas.forEach(it => {
        const btn = cont.button(Tex.whiteui, Styles.clearTogglei, 24, () => {
          self.configure(lerSel(self) == it ? null : it);
        }).group(grupo).size(44).get();
        btn.getStyle().imageUp = new TextureRegionDrawable(it.uiIcon);
        btn.update(() => btn.setChecked(lerSel(self) == it));
        if(++n % 4 == 0) cont.row();
      });
      table.add(cont).left();
    },

    config(){
      return lerSel(this);
    },

    display(table){
      this.super$display(table);
      const self = this;
      table.row();
      table.label(() => lerSel(self) == null
        ? "[lightgray]Toque no bloco e escolha o item"
        : "Produzindo: [accent]" + lerSel(self).localizedName + "[] (custo " + (CUSTO[lerSel(self).name] || 1) + " mat.)").left();
    },

    write(w){
      this.super$write(w);
      const atual = lerSel(this);
      w.i(atual == null ? -1 : atual.id);
    },

    read(r, rev){
      this.super$read(r, rev);
      const id = r.i();
      gravarSel(this, id < 0 ? null : Vars.content.item(id));
    }
  });
}

function iniciar(){
  aplicar("fabricador-universal", 30, 1);   // normal: 2 itens/s
  aplicar("fabricador-instantaneo", 1, 2);  // instantâneo: ~120 itens/s (limitado pela saída)
}

aoCarregar(iniciar);

// ---- Geradores grátis: o Melhorador de Máquinas também multiplica a energia produzida ----
function escalaTempo(build){
  const t = build.timeScale;
  return typeof t == "function" ? build.timeScale() : t;
}

function turbinar(nome){
  const b = Vars.content.getByName(ContentType.block, MOD + nome);
  if(b == null) return;
  b.buildType = () => extend(SolarGenerator.SolarGeneratorBuild, b, {
    getPowerProduction(){
      // o Melhorador multiplica a energia, mas com teto de 2,5x (evita ciclo infinito de energia)
      return this.super$getPowerProduction() * Math.min(2.5, Math.max(1, escalaTempo(this)));
    }
  });
}

function iniciarGeradores(){
  ["gerador-fraco", "gerador-medio", "gerador-bom", "gerador-otimo", "gerador-super", "gerador-colossal", "gerador-titanico"].forEach(turbinar);
}

aoCarregar(iniciarGeradores);

// ---- Melhoradores de Unidades: evoluem qualquer unidade para o próximo tier ----
const CADEIAS = [
  ["dagger", "mace", "fortress", "scepter", "reign"],
  ["nova", "pulsar", "quasar", "vela", "corvus"],
  ["crawler", "atrax", "spiroct", "arkyid", "toxopid"],
  ["flare", "horizon", "zenith", "antumbra", "eclipse"],
  ["mono", "poly", "mega", "quad", "oct"],
  ["risso", "minke", "bryde", "sei", "omura"],
  ["retusa", "oxynoe", "cyerce", "aegires", "navanax"]
];

function par(a, b){
  const A = java.lang.reflect.Array.newInstance(UnitType, 2);
  java.lang.reflect.Array.set(A, 0, a);
  java.lang.reflect.Array.set(A, 1, b);
  return A;
}

function iniciarMelhoradores(){
  ["melhorador-de-unidades", "melhorador-de-unidades-instantaneo"].forEach(nome => {
    const b = Vars.content.getByName(ContentType.block, MOD + nome);
    if(b == null) return;
    b.upgrades.clear();
    CADEIAS.forEach(cadeia => {
      for(let i = 0; i < cadeia.length - 1; i++){
        const de = Vars.content.getByName(ContentType.unit, cadeia[i]);
        const para = Vars.content.getByName(ContentType.unit, cadeia[i + 1]);
        if(de != null && para != null) b.upgrades.add(par(de, para));
      }
    });
  });
}

aoCarregar(iniciarMelhoradores);

// ---- Jogador: o núcleo passa a gerar o "Beta Hiper" (constrói/desconstrói instantaneamente) ----
const NUCLEOS = ["core-shard", "core-foundation", "core-nucleus"];

function iniciarJogador(){
  try{
    const u = Vars.content.getByName(ContentType.unit, MOD + "beta-hiper");
    if(u == null) return;
    NUCLEOS.forEach(n => {
      const c = Vars.content.getByName(ContentType.block, n);
      if(c != null) c.unitType = u;
    });
  }catch(e){
    Log.err("mega-power-pack: falha ao trocar a unidade do núcleo: " + e);
  }
}

aoCarregar(iniciarJogador);

// ---- Novos minérios: espalha manchas de Ouro, Rubi, Safira, Esmeralda e Obsidiana em mapas novos ----
const MINERIOS_NOVOS = ["minerio-ouro", "minerio-rubi", "minerio-safira", "minerio-esmeralda", "minerio-obsidiana"];

function gerarMinerios(){
  try{
    if(Vars.net.client() || Vars.state.isEditor()) return;
    if(Vars.state.rules.tags.get("mpp-minerios") != null) return; // já gerado neste mapa/save
    const ores = [];
    MINERIOS_NOVOS.forEach(n => {
      const b = Vars.content.getByName(ContentType.block, MOD + n);
      if(b != null) ores.push(b);
    });
    if(ores.length == 0) return;
    const w = Vars.world.width(), h = Vars.world.height();
    if(w < 30 || h < 30) return;
    const manchas = Math.max(3, Math.floor(w * h / 5000));
    ores.forEach(ore => {
      for(let i = 0; i < manchas; i++){
        const cx = 8 + Math.floor(Math.random() * (w - 16));
        const cy = 8 + Math.floor(Math.random() * (h - 16));
        const r = 2 + Math.floor(Math.random() * 3);
        for(let dx = -r; dx <= r; dx++){
          for(let dy = -r; dy <= r; dy++){
            if(dx * dx + dy * dy > r * r || Math.random() < 0.15) continue;
            const t = Vars.world.tile(cx + dx, cy + dy);
            if(t != null && t.block() == Blocks.air && t.overlay() == Blocks.air && !t.floor().isLiquid){
              t.setOverlay(ore);
            }
          }
        }
      }
    });
    Vars.state.rules.tags.put("mpp-minerios", "1");
  }catch(e){
    Log.err("mega-power-pack: falha ao gerar minérios: " + e);
  }
}

Events.on(WorldLoadEvent, gerarMinerios);


// ---- Minérios nas PAREDES: manchas de gemas incrustadas nas paredes (só aparecem perto de espaços abertos) ----
const MINERIOS_PAREDE = ["minerio-parede-ouro", "minerio-parede-rubi", "minerio-parede-safira", "minerio-parede-esmeralda", "minerio-parede-obsidiana"];
const StaticWallCls = Packages.mindustry.world.blocks.environment.StaticWall;

function paredeExposta(t){
  const viz = [[1, 0], [-1, 0], [0, 1], [0, -1]];
  for(let i = 0; i < viz.length; i++){
    const n = Vars.world.tile(t.x + viz[i][0], t.y + viz[i][1]);
    if(n != null && !(n.block() instanceof StaticWallCls)) return true;
  }
  return false;
}

function gerarMinerosParede(){
  try{
    if(Vars.net.client() || Vars.state.isEditor()) return;
    if(Vars.state.rules.tags.get("mpp-paredes") != null) return;
    const ores = [];
    MINERIOS_PAREDE.forEach(n => {
      const b = Vars.content.getByName(ContentType.block, MOD + n);
      if(b != null) ores.push(b);
    });
    if(ores.length == 0) return;
    const w = Vars.world.width(), h = Vars.world.height();
    if(w < 30 || h < 30) return;
    const alvo = Math.max(4, Math.floor(w * h / 6000));
    ores.forEach(ore => {
      let feitas = 0;
      for(let tent = 0; tent < alvo * 60 && feitas < alvo; tent++){
        const x = 2 + Math.floor(Math.random() * (w - 4));
        const y = 2 + Math.floor(Math.random() * (h - 4));
        const t = Vars.world.tile(x, y);
        if(t == null || !(t.block() instanceof StaticWallCls) || !paredeExposta(t)) continue;
        for(let dx = -2; dx <= 2; dx++){
          for(let dy = -2; dy <= 2; dy++){
            if(dx * dx + dy * dy > 5 || Math.random() < 0.2) continue;
            const o = Vars.world.tile(x + dx, y + dy);
            if(o != null && o.block() instanceof StaticWallCls && o.overlay() == Blocks.air && paredeExposta(o)){
              o.setOverlay(ore);
            }
          }
        }
        feitas++;
      }
    });
    Vars.state.rules.tags.put("mpp-paredes", "1");
  }catch(e){
    Log.err("mega-power-pack: falha ao gerar minérios de parede: " + e);
  }
}

Events.on(WorldLoadEvent, gerarMinerosParede);

// ---- Brocas especializadas: 3x mais rápidas no minério do seu nome ----
const ESPECIALIDADES = {
  "broca-nova-1": "ouro", "broca-nova-2": "rubi", "broca-nova-3": "safira",
  "broca-nova-4": "esmeralda", "broca-nova-5": "obsidiana",
  "perfuratriz-1": "ouro", "perfuratriz-2": "rubi", "perfuratriz-3": "safira",
  "perfuratriz-4": "esmeralda", "perfuratriz-5": "obsidiana"
};

function iniciarEspecialidades(){
  Object.keys(ESPECIALIDADES).forEach(nome => {
    try{
      const b = Vars.content.getByName(ContentType.block, MOD + nome);
      const it = Vars.content.getByName(ContentType.item, MOD + ESPECIALIDADES[nome]);
      if(b != null && it != null) b.drillMultipliers.put(it, 3);
    }catch(e){
      Log.err("mega-power-pack: não consegui definir a especialidade de " + nome + ": " + e);
    }
  });
}

aoCarregar(iniciarEspecialidades);

Log.info("[mega-power-pack] carregado - jogadores e servidor precisam do mesmo mod e da mesma versão para jogar online.");
